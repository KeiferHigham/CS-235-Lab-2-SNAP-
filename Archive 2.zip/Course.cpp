
#include "Course.h"

string Course::GetCourse() const {

    return course;
}

