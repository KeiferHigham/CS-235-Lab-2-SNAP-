
#include "csgs.h"

csgs::csgs(string courseNum, string id, string grade) {
numOfCourse = courseNum;
studentId = id;
studentGrade = grade;
}

